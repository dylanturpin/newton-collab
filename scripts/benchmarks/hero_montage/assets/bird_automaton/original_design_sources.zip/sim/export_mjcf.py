"""Export two MuJoCo scenes using real joint axes and explicit contact geometry.
The contact-gears variant has NO equality constraints; the ideal-gears variant
has two gear-ratio constraints. Both use passive contact-driven wings and jaw.
"""
from __future__ import annotations
import sys,json,math,xml.etree.ElementTree as ET
from pathlib import Path
import numpy as np
import cadquery as cq
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
from design import P,gear_tooth,GEAR_PHASE
from build_cad import poly_yz
D=json.loads((ROOT/'cad'/'manifest.json').read_text())

def s(v):
    if isinstance(v,(list,tuple,np.ndarray)):return ' '.join(f'{float(x):.10g}' for x in v)
    return str(v)

def E(parent,tag,**attrs):return ET.SubElement(parent,tag,{k:s(v) for k,v in attrs.items()})

def properties(name,rho,offset=(0,0,0)):
    sh=cq.importers.importStep(str(ROOT/'cad'/(name+'.step'))).val()
    m=sh.Volume()*rho*1e-9;c=np.array(sh.Center().toTuple())*.001+np.asarray(offset)
    I=np.asarray(cq.Shape.matrixOfInertia(sh))*rho*1e-15
    return m,c,I

def inertial(b,components):
    parts=[properties(*co) for co in components];m=sum(x[0] for x in parts)
    c=sum(mi*ci for mi,ci,_ in parts)/m;I=np.zeros((3,3))
    for mi,ci,Ii in parts:
        r=ci-c;I+=Ii+mi*(np.dot(r,r)*np.eye(3)-np.outer(r,r))
    E(b,'inertial',mass=m,pos=c,fullinertia=[I[0,0],I[1,1],I[2,2],I[0,1],I[0,2],I[1,2]])

def visual(b,name,pos=(0,0,0)):
    E(b,'geom',name=name+'_visual',type='mesh',mesh=name,pos=pos,rgba=[*D[name]['color'],1],group=1)


def export(ideal):
    root=ET.Element('mujoco',model='contact_driven_bird')
    E(root,'compiler',angle='radian',meshdir='../cad',inertiafromgeom='false',autolimits='true')
    E(root,'option',timestep=.0005,gravity=[0,0,-9.81],integrator='implicitfast',solver='Newton',iterations=80,tolerance='1e-10',cone='elliptic')
    defs=E(root,'default');E(defs,'geom',contype=0,conaffinity=0,condim=1,friction=[.03,.001,.0001],solref=[.004,1],solimp=[.95,.99,.001],margin=.00001)
    E(defs,'joint',damping=.00001,armature='1e-8')
    vis=E(root,'visual');E(vis,'global',offwidth=1600,offheight=1200);E(vis,'headlight',diffuse=[.8,.8,.8],ambient=[.4,.4,.4])
    E(root,'statistic',center=[-.005,-.015,.13],extent=.34)
    asset=E(root,'asset')
    for name in D:E(asset,'mesh',name=name,file=name+'.stl',scale=[.001]*3)
    for n in P['gear_teeth']:
        path=ROOT/'cad'/f'tooth_{n}.stl'
        cq.exporters.export(poly_yz(gear_tooth(n),-4,8),str(path),tolerance=.02)
        E(asset,'mesh',name=f'tooth_{n}',file=path.name,scale=[.001]*3)
    w=E(root,'worldbody');E(w,'light',pos=[-.2,-.4,.7],dir=[.3,.4,-1],diffuse=[.7,.7,.7])
    E(w,'camera',name='overview',pos=[-.41,-.59,.34],xyaxes=[.821,-.571,0,.186,.267,.946])
    for name,d in D.items():
        if d['motion'] is None:visual(w,name)
    geomgear=[]
    names=['input','idler','output'];pc=['input_gear','idler_gear','output_gear_shaft']
    for i,(n,y) in enumerate(zip(P['gear_teeth'],P['gear_y'])):
        b=E(w,'body',name=names[i]+'_rotor',pos=[-.068,y*.001,.065])
        E(b,'joint',name=names[i]+'_angle',type='hinge',axis=[1,0,0],damping=.00001)
        comps=[(pc[i],750)]
        if i==2:comps += [('wing_eccentric_cam',1100,(.044,0,0)),('beak_dwell_cam',1100,(.101,0,0))]
        inertial(b,comps);visual(b,pc[i]);bit=0 if ideal else 1
        E(b,'geom',name=names[i]+'_root',type='cylinder',size=[(n-2.5)*.001,.004],quat=[.7071067812,0,.7071067812,0],contype=bit,conaffinity=bit,group=3,rgba=[.5,.5,.5,0])
        for k in range(n):
            angle=2*np.pi*k/n+GEAR_PHASE[i]
            E(b,'geom',name=f'{names[i]}_tooth_{k}',type='mesh',mesh=f'tooth_{n}',quat=[np.cos(angle/2),np.sin(angle/2),0,0],contype=bit,conaffinity=bit,group=3,rgba=[.5,.5,.5,0])
        if i==2:
            visual(b,'wing_eccentric_cam',pos=[.044,0,0]);visual(b,'beak_dwell_cam',pos=[.101,0,0])
            E(b,'geom',name='wing_cam_contact',type='cylinder',size=[.020,.004],pos=[.044,0,-P['wing_e']*.001],quat=[.7071067812,0,.7071067812,0],group=3,rgba=[1,0,0,0])
            E(b,'geom',name='beak_cam_contact',type='mesh',mesh='beak_dwell_cam',pos=[.101,0,0],group=3,rgba=[1,0,0,0])
    b=E(w,'body',name='wing_fork',pos=[0,0,P['wing_foot_z']*.001]);E(b,'joint',name='fork_z',type='slide',axis=[0,0,1],range=[-.002,.024],damping=.03)
    inertial(b,[('wing_lifting_fork',1100)]);visual(b,'wing_lifting_fork')
    E(b,'geom',name='fork_cam_foot',type='box',size=[.005,.018,.002],pos=[-.024,0,.002],group=3,rgba=[0,0,1,0])
    for sy in [-1,1]:E(b,'geom',name='fork_pad_'+str(sy),type='box',size=[.004,.005,.002],pos=[-.048,sy*.0383,.100],group=3,rgba=[0,0,1,0])
    for sy,name in [(1,'wing_left'),(-1,'wing_right')]:
        al=-np.deg2rad(35)
        b=E(w,'body',name=name,pos=[0,sy*.022,.190],quat=[np.cos(al/2),sy*np.sin(al/2),0,0])
        E(b,'joint',name=name+'_angle',type='hinge',axis=[sy,0,0],ref=al,range=np.deg2rad([-42,45]),damping=.00001)
        inertial(b,[(name,750)]);visual(b,name)
        E(b,'geom',name=name+'_shoe',type='cylinder',size=[.003,.007],pos=[-.045,sy*.018,0],quat=[.7071067812,0,.7071067812,0],group=3,rgba=[1,0,1,0])
    b=E(w,'body',name='beak_slider',pos=[0,0,P['beak_foot_z']*.001]);E(b,'joint',name='beak_slide_z',type='slide',axis=[0,0,1],range=[-.002,.011],damping=.03)
    inertial(b,[('beak_pushrod',1100)]);visual(b,'beak_pushrod')
    E(b,'geom',name='beak_cam_foot',type='box',size=[.005,.016,.002],pos=[.033,0,.002],group=3,rgba=[0,0,1,0])
    E(b,'geom',name='beak_lifting_pad',type='box',size=[.0055,.004,.002],pos=[.0335,-.008,.1305],group=3,rgba=[0,0,1,0])
    b=E(w,'body',name='jaw',pos=[.050,0,.218]);E(b,'joint',name='jaw_angle',type='hinge',axis=[0,1,0],range=[0,np.deg2rad(35)],damping=.000002)
    inertial(b,[('lower_beak',750),('beak_counterweight',7800)]);visual(b,'lower_beak');visual(b,'beak_counterweight')
    E(b,'geom',name='jaw_shoe',type='cylinder',size=[.0025,.007],pos=[-.018,-.005,0],quat=[.7071067812,.7071067812,0,0],group=3,rgba=[1,0,1,0])
    contact=E(root,'contact')
    for a,b in [('wing_cam_contact','fork_cam_foot'),('wing_left_shoe','fork_pad_1'),('wing_right_shoe','fork_pad_-1'),('beak_cam_contact','beak_cam_foot'),('jaw_shoe','beak_lifting_pad')]:
        E(contact,'pair',geom1=a,geom2=b,condim=1,margin=.00001)
    if ideal:
        eq=E(root,'equality')
        E(eq,'joint',joint1='idler_angle',joint2='input_angle',polycoef=[0,-24/20,0,0,0])
        E(eq,'joint',joint1='output_angle',joint2='input_angle',polycoef=[0,24/36,0,0,0])
    act=E(root,'actuator');E(act,'velocity',name='crank_drive',joint='input_angle',kv=.025,forcerange=[-.05,.05],ctrlrange=[-10,10])
    ET.indent(root,space='  ')
    filename='bird_ideal_gears.xml' if ideal else 'bird_contact_gears.xml'
    ET.ElementTree(root).write(ROOT/'sim'/filename,encoding='utf-8',xml_declaration=True)
    print(filename)

if __name__=='__main__':
    export(True);export(False)
