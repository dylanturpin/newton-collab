"""Dimensioned bird automaton. CAD units mm; physics units SI."""
from __future__ import annotations
import numpy as np
from math import pi, sin, cos, sqrt

# Design parameters in millimetres.
P = dict(wing_hinge_z=190., shoulder_y=22., wing_arm=18., wing_angle_deg=35.,
         wing_shoe_r=3., wing_shoe_x=-48., camshaft_z=65., wing_cam_x=-24.,
         wing_cam_r=20., beak_cam_x=33., beak_cam_r=18., beak_lift=9.,
         jaw_hinge_x=50., jaw_hinge_z=218., jaw_arm=18., jaw_shoe_r=2.5,
         beak_tip=32., beak_counterweight_x=-28., module=2., pressure_angle=20.,
         gear_teeth=(24,20,36), gear_y=(-100.,-56.,0.), gear_x=-68.,
         output_hz=.6, backlash=.20)
P['wing_e'] = P['wing_arm']*sin(np.deg2rad(P['wing_angle_deg']))
P['wing_foot_z'] = P['camshaft_z']+P['wing_cam_r']-P['wing_e']
P['wing_pad_offset'] = P['wing_hinge_z']-P['camshaft_z']-P['wing_cam_r']-P['wing_shoe_r']
P['beak_foot_z'] = P['camshaft_z']+P['beak_cam_r']
P['beak_pad_offset'] = P['jaw_hinge_z']-P['jaw_shoe_r']-P['beak_foot_z']


def beak_lift(theta):
    """9 mm raised-cosine lobe with a 180-degree closed-mouth dwell."""
    t = np.asarray(theta)%(2*pi)
    inside = (t > pi/2)&(t < 3*pi/2)
    q = np.where(inside, P['beak_lift']*np.cos(t)**2, 0.)
    dq = np.where(inside, -P['beak_lift']*np.sin(2*t), 0.)
    ddq = np.where(inside, -2*P['beak_lift']*np.cos(2*t), 0.)
    return q, dq, ddq


def beak_profile(n=720):
    """Envelope for a translating FLAT follower, NOT a naive polar lobe.
    n(theta)=(sin(theta),cos(theta)); p=s*n+s'*n'.
    This compensates tangency migration and produces the intended lift.
    """
    t = np.linspace(0,2*pi,n,endpoint=False)
    q,dq,_=beak_lift(t)
    s=P['beak_cam_r']+q
    return np.column_stack((s*np.sin(t)+dq*np.cos(t),s*np.cos(t)-dq*np.sin(t)))


def pose(theta):
    qw=P['wing_e']*(1-np.cos(theta))
    qb=beak_lift(theta)[0]
    alpha=np.arcsin((qw-P['wing_e'])/P['wing_arm'])
    beta=np.arcsin(qb/P['jaw_arm'])
    return dict(theta=float(theta),qw=float(qw),qb=float(qb),alpha=float(alpha),beta=float(beta))


def gear_tooth(n, samples=12):
    """One 20-degree involute tooth polygon, centered on +Y in a YZ section.
    Polygonal involute approximation; root transition is radial, not a cutter fillet.
    """
    m=P['module']; rp=n*m/2; rb=rp*cos(np.deg2rad(P['pressure_angle']))
    ra=rp+m; rr=rp-1.25*m
    inv=lambda r: sqrt(max(0,(r/rb)**2-1))-np.arccos(min(1,rb/r))
    half=pi/(2*n)-P['backlash']/(2*rp)
    rs=np.linspace(max(rb,rr),ra,samples)
    off=np.array([half+inv(rp)-inv(r) for r in rs])
    pts=[(rr*cos(off[0]),-rr*sin(off[0]))]
    pts += [(r*cos(a),-r*sin(a)) for r,a in zip(rs,off)]
    pts += [(ra*cos(a),ra*sin(a)) for a in np.linspace(-off[-1],off[-1],5)[1:]]
    pts += [(r*cos(a),r*sin(a)) for r,a in zip(rs[-2::-1],off[-2::-1])]
    pts += [(rr*cos(off[0]),rr*sin(off[0]))]
    return np.asarray(pts)

# Gear angular offsets: tooth against space on each line of centres.
GEAR_PHASE=(0., pi/20, 0.)

if __name__=='__main__':
    for deg in [0,90,180,270,360]:
        p=pose(np.deg2rad(deg)); print(deg,{k:round(v,4) for k,v in p.items()})
    print(P)
