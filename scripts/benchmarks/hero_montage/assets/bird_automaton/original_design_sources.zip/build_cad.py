"""Build real CadQuery B-rep solids and export STEP/STL plus an assembly manifest.
Run: python build_cad.py. The scene is an open, inspectable mechanism, not a housing design.
"""
from __future__ import annotations
import json, math
from pathlib import Path
import numpy as np
import cadquery as cq
from design import P, pose, beak_profile, gear_tooth, GEAR_PHASE
ROOT=Path(__file__).resolve().parent
CAD=ROOT/'cad'; CAD.mkdir(exist_ok=True)
COLORS={'frame':(.28,.32,.36),'gear':(.79,.64,.32),'cam':(.84,.40,.18),
        'yoke':(.12,.52,.64),'wing':(.78,.62,.37),'jaw':(.82,.43,.19),
        'steel':(.63,.69,.74),'body':(.89,.85,.74),'weight':(.3,.33,.37)}

def box(x,y,z,center):
    return cq.Workplane('XY').box(x,y,z).translate(center).val()

def cyl(r,l,center,axis='z'):
    obj=cq.Workplane('XY').circle(r).extrude(l/2,both=True).val()
    if axis=='x':obj=obj.rotate((0,0,0),(0,1,0),90)
    if axis=='y':obj=obj.rotate((0,0,0),(1,0,0),90)
    return obj.translate(center)

def poly_yz(points,x0,width):
    return cq.Workplane('YZ',origin=(x0,0,0)).polyline([tuple(p) for p in points]).close().extrude(width).val()

def poly_xz(points,y0,width):
    # XZ normal is -Y.
    return cq.Workplane('XZ',origin=(0,y0+width,0)).polyline([tuple(p) for p in points]).close().extrude(width).val()

def union(items):
    out=items[0]
    for item in items[1:]:out=out.fuse(item)
    return out.clean()

def gear(n):
    rr=n*P['module']/2-1.25*P['module']
    arr=[cyl(rr,8,(0,0,0),'x')]
    tooth=poly_yz(gear_tooth(n),-4,8)
    arr += [tooth.rotate((0,0,0),(1,0,0),i*360/n) for i in range(n)]
    g=union(arr)
    return g.cut(cyl(3.1,10,(0,0,0),'x'))

def frame():
    f=[box(170,246,10,(-5,-15,5))]
    for y in P['gear_y']:
        post=box(10,14,69,(-55,y,44.5))
        f.append(post.cut(cyl(3.15,12,(-55,y,65),'x')))
    f.append(box(10,14,69,(47,0,44.5)).cut(cyl(3.15,12,(47,0,65),'x')))
    # Fixed torso support: twin columns, clear of the camshaft and both pushrods.
    for sy in [-1,1]:
        f.append(box(10,8,157,(0,sy*16,88.5)))
        # Wing bearings at the fixed longitudinal hinge axes.
        for x in [-12,8]:
            bracket=box(7,14,14,(x,sy*21,190))
            f.append(bracket.cut(cyl(3.15,10,(x,sy*22,190),'x')))
    # Guide collars around each fork upright, 0.2 mm radial clearance.
    for sy in [-1,1]:
        collar=box(12,12,15,(-48,sy*38.3,143))
        collar=collar.cut(box(4.4,4.4,18,(-48,sy*38.3,143)))
        f += [collar,box(12,12,141,(-36,sy*38.3,80.5)),box(8,12,12,(-41,sy*38.3,143))]
    # Two beak guide collars. Offset tongue connects them to the torso column.
    for z in [126,172]:
        f += [box(12,12,10,(33,-8,z)).cut(cyl(2.7,12,(33,-8,z),'z')),
              box(33,6,8,(16.5,-18,z)),box(6,8,8,(33,-17,z))]
    return cq.Compound.makeCompound(f)

def bird_body():
    # Flat paired cheek/torso plates leave the neck mechanism inspectable.
    outline=[(-31,169),(-43,174),(-31,180),(-28,195),(-18,206),(7,211),
             (23,217),(27,231),(37,239),(50,239),(59,232),(61,222),(55,213),
             (46,207),(35,182),(21,172),(1,166)]
    pieces=[]
    for y in [-18,14]:
        s=poly_xz(outline,y,4).cut(cyl(3.15,6,(50,y+2,218),'y'))
        # Cutaway window exposes the moving jaw tail and counterweight.
        s=s.cut(box(34,8,19,(30,y+2,218)))
        pieces.append(s)
    # Upper beak, rigidly fixed, lower surface clears closed lower jaw.
    upper=poly_xz([(55,221),(82,224),(61,230)],-7,14)
    pieces += [upper,box(14,28,6,(50,0,233)),cyl(3,43,(50,0,218),'y')]
    # Tail is integral to the fixed bird body, not an actuator.
    pieces.append(poly_xz([(-28,176),(-60,185),(-51,172),(-28,169)],-8,16))
    return cq.Compound.makeCompound(pieces)

def wing(sy):
    # Joint origin (0, +/-22, 190), +X/-X axis respectively.
    outline=[(8,10),(20,22),(16,40),(8,64),(-5,79),(-17,75),(-13,57),
             (-25,70),(-29,63),(-22,42),(-35,52),(-39,42),(-31,20),(-24,10)]
    outline=[(x,sy*y) for x,y in outline]
    blade=cq.Workplane('XY',origin=(0,0,-1.75)).polyline(outline).close().extrude(3.5).val()
    # Root shaft, external crank arm and a laterally-offset rounded sliding shoe.
    # The offset prevents the lifting shelf from hitting the wing sheet / crank arm.
    arm=box(4,18,4,(-40,sy*9,0))
    items=[blade,box(5,14,5,(-2,sy*7,0)),cyl(3,56,(-14,0,0),'x'),arm,cyl(4,4,(-40,0,0),'x'),
           cyl(3,14,(-45,sy*18,0),'x')]
    return union(items)

def wing_yoke():
    # Local zero Z is the underside of the cam follower at its lowest position.
    H=P['wing_pad_offset']
    items=[box(10,36,4,(-24,0,2)),box(5,5,24,(-24,0,16)),
           box(29,7,5,(-36,0,25)),box(7,84,5,(-48,0,25))]
    for sy in [-1,1]:
        items += [box(4,4,H-25,(-48,sy*38.3,(25+H)/2)),
                  box(8,10,4,(-48,sy*38.3,H-2))]
    return union(items)

def beak_slider():
    H=P['beak_pad_offset']
    return union([box(10,32,4,(33,0,2)),cyl(2.5,H-4,(33,-8,(H+4)/2),'z'),
                  box(11,8,4,(33.5,-8,H-2))])

def jaw():
    # Origin at the jaw hinge. +Y rotation lowers the front tip and raises its tail.
    front=poly_xz([(0,-2.5),(32,0),(0,1.5)],-5,10)
    arm=box(28,4,3,(-14,0,0))
    shoe=cyl(2.5,14,(-18,-5,0),'y')
    hub=cyl(4.5,12,(0,0,0),'y').cut(cyl(3.15,14,(0,0,0),'y'))
    # The counterweight is assigned its own metal density in the dynamics model.
    return union([front,arm,shoe,hub]).cut(cyl(3.15,16,(0,0,0),'y'))


def build():
    parts={}
    def add(name,shape,color,origin=(0,0,0),axis=None,motion=None):
        if not shape.isValid():raise RuntimeError('Invalid B-rep: '+name)
        cq.exporters.export(shape,str(CAD/(name+'.step')))
        cq.exporters.export(shape,str(CAD/(name+'.stl')),tolerance=.06,angularTolerance=.12)
        parts[name]=dict(shape=shape,color=COLORS[color],origin=origin,axis=axis,motion=motion,
                         volume_mm3=shape.Volume(),valid=shape.isValid())
    add('frame',frame(),'frame')
    add('fixed_bird_body',bird_body(),'body')
    for i,(n,y) in enumerate(zip(P['gear_teeth'],P['gear_y'])):
        g=gear(n).rotate((0,0,0),(1,0,0),np.rad2deg(GEAR_PHASE[i]))
        if i==0:
            g=union([g,cyl(3,35,(2.5,0,0),'x'),box(5,5,27,(-14,0,-10)),cyl(4,17,(-21,0,-23),'x')])
        elif i==1:g=union([g,cyl(3,35,(2.5,0,0),'x')])
        else:g=union([g,cyl(3,135,(55.5,0,0),'x')])
        add(['input_gear','idler_gear','output_gear_shaft'][i],g,'gear',(P['gear_x'],y,65),'x',['input','idler','output'][i])
    cam=cyl(P['wing_cam_r'],8,(0,0,-P['wing_e']),'x')
    cam=cam.cut(cyl(3.1,10,(0,0,0),'x'))
    add('wing_eccentric_cam',cam,'cam',(-24,0,65),'x','output')
    beakcam=poly_yz(beak_profile(),-4,8).cut(cyl(3.1,10,(0,0,0),'x'))
    add('beak_dwell_cam',beakcam,'cam',(33,0,65),'x','output')
    add('wing_lifting_fork',wing_yoke(),'yoke',(0,0,P['wing_foot_z']),'z','qw')
    add('beak_pushrod',beak_slider(),'yoke',(0,0,P['beak_foot_z']),'z','qb')
    for sy in [-1,1]:add('wing_'+('left' if sy==1 else 'right'),wing(sy),'wing',(0,sy*22,190),'x','alpha'+str(sy))
    add('lower_beak',jaw(),'jaw',(50,0,218),'y','beta')
    add('beak_counterweight',cyl(5.5,12,(-28,0,0),'y'),'weight',(50,0,218),'y','beta')
    # Exposed eyes are aesthetic, fixed pieces.
    for sy in [-1,1]:add('eye_'+str(sy),cyl(2,1.6,(46,sy*19,231),'y'),'weight')
    assy=cq.Assembly(name='Bird_Automaton_Low_Pose')
    manifest={}
    p=pose(0)
    for name,d in parts.items():
        shp=transform(d,p)
        assy.add(shp,name=name,color=cq.Color(*d['color']))
        manifest[name]={k:v for k,v in d.items() if k!='shape'}
    assy.export(str(CAD/'bird_automaton.step'))
    (CAD/'manifest.json').write_text(json.dumps(manifest,indent=2))
    (ROOT/'parameters.json').write_text(json.dumps(P,indent=2))
    print('Built',len(parts),'valid CAD parts')
    print('Assembly:',CAD/'bird_automaton.step')
    return parts


def transform(d,p):
    shape=d['shape']; motion=d['motion']; angle=0
    if motion=='input':angle=p['theta']*36/24
    if motion=='idler':angle=-p['theta']*36/20
    if motion=='output':angle=p['theta']
    if motion=='alpha1':angle=p['alpha']
    if motion=='alpha-1':angle=-p['alpha']
    if motion=='beta':angle=p['beta']
    if angle:shape=shape.rotate((0,0,0),(1,0,0) if d['axis']=='x' else (0,1,0),np.rad2deg(angle))
    origin=np.array(d['origin'],float)
    if motion in ['qw','qb']:origin[2]+=p[motion]
    return shape.translate(tuple(origin))

if __name__=='__main__':build()
